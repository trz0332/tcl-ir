from __future__ import annotations
import os.path
import logging
from custom_components.smartac.const import CONF_CONTROLLER_DATA, CONF_CONTROLLER_TYPE
from custom_components.smartac.controller import ESPHOME_CONTROLLER
from homeassistant.const import Platform
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

_LOGGER = logging.getLogger(__name__)

COMPONENT_ABS_DIR = os.path.dirname(
    os.path.abspath(__file__))

CODES_AB_DIR = os.path.join(COMPONENT_ABS_DIR, 'codes')

PLATFORMS = [Platform.CLIMATE]


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry
) -> bool:
    """Set up SmartAC from a config entry."""
    # 监听 options 更新事件，确保配置修改后自动重载
    entry.async_on_unload(
        entry.add_update_listener(_async_update_listener)
    )
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(
    hass: HomeAssistant, config_entry: ConfigEntry
) -> bool:
    """Unload a config entry."""
    return await hass.config_entries.async_unload_platforms(config_entry, PLATFORMS)


async def _async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Handle options update."""
    _LOGGER.debug("SmartAC options updated, reloading entry: %s", entry.entry_id)
    await hass.config_entries.async_reload(entry.entry_id)


async def async_migrate_entry(hass: HomeAssistant, config_entry: ConfigEntry) -> bool:
    """Migrate old entry."""
    if config_entry.version == 1:
        data = {**config_entry.data, CONF_CONTROLLER_TYPE:ESPHOME_CONTROLLER}
        data[CONF_CONTROLLER_DATA] = data['controller_service']
        data.pop('controller_service')
        config_entry.version = 2
        hass.config_entries.async_update_entry(
                config_entry,
                data = data,
            )    

    return True
