from collections import defaultdict
from homeassistant.components.climate import HVACMode  # 使用新的 HVACMode 枚举
from .irext import MODE_AUTO, MODE_COOL, MODE_DRY, MODE_FAN, MODE_HEAT
from .irext import SPEED_AUTO, SPEED_HIGH, SPEED_LOW, SPEED_MEDIUM
from .irext import POWER_OFF, POWER_ON
from .irext import AC

# 映射 HVAC 模式到新的 HVACMode 枚举
mode_map = {
    MODE_AUTO: HVACMode.AUTO,
    MODE_COOL: HVACMode.COOL,
    MODE_DRY: HVACMode.DRY,
    MODE_FAN: HVACMode.FAN_ONLY,
    MODE_HEAT: HVACMode.HEAT
}

# 映射风扇模式到 Home Assistant 标准字符串（小写）
speed_map = {
    SPEED_AUTO: "auto",
    SPEED_HIGH: "high",
    SPEED_LOW: "low",
    SPEED_MEDIUM: "medium"
}

def bin_to_json(bin_data):
    """Convert binary IR data to JSON format compatible with Home Assistant."""
    decode_json = {
        'manufacturer': 'hass',
        'precision': 1
    }

    ac = AC(bin_data)
    modes = ac.get_supported_mode()
    
    # 使用 HVACMode 枚举的 value 属性获取字符串
    decode_json['operationModes'] = [mode_map[m].value for m in modes]

    speeds = set()
    temperature = set()

    decode_json["commands"] = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    
    for m in modes:
        for s in (ac.get_supported_wind_speed(m) or [SPEED_AUTO]):
            speeds.add(s)
            for t in (ac.get_temperature_range(m) or [26]):
                temperature.add(t)
                # 使用模式字符串和风扇字符串
                mode_key = mode_map[m].value
                speed_key = speed_map[s]
                temperature_key = f"{t}"
                raw = ac.ir_decode(POWER_ON, t, m, s)
                decode_json["commands"][mode_key][speed_key][temperature_key] = raw

    # 处理关机指令
    raw = ac.ir_decode(POWER_OFF, 26, MODE_AUTO, SPEED_AUTO)
    decode_json["commands"]["off"] = raw

    # 风扇模式列表
    decode_json['fanModes'] = [speed_map[s] for s in speeds]
    decode_json['minTemperature'] = min(temperature)
    decode_json['maxTemperature'] = max(temperature)
   
    return decode_json